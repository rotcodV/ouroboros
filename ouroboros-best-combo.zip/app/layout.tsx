import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "OUROBOROS — Every End Is A New Beginning",
  description: "A premium motion-led digital experience using Next.js, Framer Motion, GSAP, and Three.js."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
