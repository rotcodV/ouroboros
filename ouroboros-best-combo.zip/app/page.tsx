'use client';

import dynamic from "next/dynamic";
import Image from "next/image";
import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

const OuroborosScene = dynamic(() => import("@/components/OuroborosScene"), {
  ssr: false
});

const fade = {
  hidden: { opacity: 0, y: 34 },
  show: { opacity: 1, y: 0 }
};

export default function Home() {
  const pageRef = useRef<HTMLElement | null>(null);
  const { scrollYProgress } = useScroll();
  const heroLift = useTransform(scrollYProgress, [0, 0.35], [0, -90]);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>(".gsap-reveal").forEach((el) => {
        gsap.fromTo(
          el,
          { opacity: 0, y: 44 },
          {
            opacity: 1,
            y: 0,
            duration: 1,
            ease: "power3.out",
            scrollTrigger: {
              trigger: el,
              start: "top 84%"
            }
          }
        );
      });

      gsap.to(".image-card", {
        scale: 0.92,
        opacity: 0.88,
        ease: "none",
        scrollTrigger: {
          trigger: ".hero",
          start: "top top",
          end: "bottom top",
          scrub: true
        }
      });
    }, pageRef);

    return () => ctx.revert();
  }, []);

  return (
    <main ref={pageRef}>
      <div className="noise" />

      <nav className="nav">
        <a href="#" className="logo">OUROBOROS</a>
        <div className="navlinks">
          <a href="#symbol">Symbol</a>
          <a href="#cycle">Cycle</a>
          <a href="#manifesto">Manifesto</a>
        </div>
      </nav>

      <section className="hero">
        <motion.div initial="hidden" animate="show" transition={{ staggerChildren: 0.14 }}>
          <motion.p className="kicker" variants={fade}>Next.js / Framer / GSAP / Three.js</motion.p>
          <motion.h1 variants={fade}>Every End<br />Is A New<br />Beginning</motion.h1>
          <motion.p className="hero-copy" variants={fade}>
            Ouroboros is the discipline of returning to yourself — shedding what has expired,
            absorbing the lesson, and entering the next cycle with sharper intent.
          </motion.p>
          <motion.div className="actions" variants={fade}>
            <a className="btn primary" href="#symbol">Enter the cycle</a>
            <a className="btn" href="#manifesto">Read manifesto</a>
          </motion.div>
        </motion.div>

        <motion.div className="visual" style={{ y: heroLift }}>
          <div className="three">
            <OuroborosScene />
          </div>
          <motion.div
            className="image-card"
            initial={{ opacity: 0, scale: .94, rotateX: 5 }}
            animate={{ opacity: 1, scale: 1, rotateX: 0 }}
            transition={{ duration: 1.1, ease: "easeOut" }}
            whileHover={{ rotateY: 4, rotateX: -3, scale: 1.015 }}
          >
            <Image
              src="/ouroboros-hero.png"
              alt="Black minimalist fashion image inspired by the Ouroboros symbol"
              width={900}
              height={1200}
              priority
            />
          </motion.div>
        </motion.div>
      </section>

      <div className="marquee">
        <span>OUROBOROS · RENEWAL · DISCIPLINE · RETURN · TRANSFORMATION · EVERY END IS A NEW BEGINNING · OUROBOROS · RENEWAL · DISCIPLINE · RETURN · TRANSFORMATION · EVERY END IS A NEW BEGINNING · </span>
      </div>

      <section className="section two" id="symbol">
        <div className="gsap-reveal">
          <p className="kicker">The Symbol</p>
          <h2>The serpent closes the circle.</h2>
        </div>

        <div className="cards">
          {[
            ["01", "Endings are not failures."],
            ["02", "The cycle only punishes refusal."],
            ["03", "Renewal requires sacrifice."],
            ["04", "What returns must return transformed."]
          ].map(([num, text]) => (
            <div className="card gsap-reveal" key={num}>
              <span>{num}</span>
              <strong>{text}</strong>
            </div>
          ))}
        </div>
      </section>

      <section className="section" id="cycle">
        <div className="two">
          <div className="gsap-reveal">
            <p className="kicker">The Cycle</p>
            <h2>Destroy. Digest. Design. Return.</h2>
          </div>
          <p className="copy gsap-reveal">
            The Ouroboros is not passive. It is a brutal symbol of self-renewal.
            The old version must be consumed before the new one can be built.
            In fashion, identity, business, and personal evolution, the loop is the same:
            remove excess, preserve essence, and return with intent.
          </p>
        </div>

        <div className="grid">
          {[
            ["01", "Destroy", "End what no longer carries the future."],
            ["02", "Digest", "Extract the lesson without worshipping the pain."],
            ["03", "Design", "Build the next form deliberately."],
            ["04", "Return", "Re-enter the world with sharper standards."],
            ["05", "Repeat", "The cycle continues until the identity is refined."],
            ["06", "Become", "Every loop leaves a cleaner silhouette."]
          ].map(([num, title, copy]) => (
            <article className="tile gsap-reveal" key={title}>
              <span>{num}</span>
              <div>
                <h3>{title}</h3>
                <p>{copy}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section final" id="manifesto">
        <div className="final-inner gsap-reveal">
          <p className="kicker">Manifesto</p>
          <h2>You are not starting over. You are returning with evidence.</h2>
          <p className="copy" style={{ maxWidth: 700, margin: "30px auto 0" }}>
            The circle is not a trap. It is a forge. Each ending exposes what was weak.
            Each return proves what survived.
          </p>
        </div>
      </section>

      <footer className="footer">
        <span>OUROBOROS / 2026</span>
        <span>Every end is a new beginning</span>
      </footer>
    </main>
  );
}
