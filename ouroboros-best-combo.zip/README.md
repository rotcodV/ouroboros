# Ouroboros — Best Combo Motion Site

Built with:

- Next.js
- Framer Motion
- GSAP + ScrollTrigger
- Three.js via React Three Fiber
- Vercel-ready structure

## Run locally

```bash
npm install
npm run dev
```

## Deploy to Vercel

1. Push this folder to GitHub.
2. Import the repo into Vercel.
3. Framework preset: Next.js.
4. Deploy.
