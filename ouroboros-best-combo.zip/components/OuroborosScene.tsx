'use client';

import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Stars } from "@react-three/drei";
import { useRef } from "react";
import * as THREE from "three";

function Ring() {
  const ref = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (!ref.current) return;
    ref.current.rotation.z = state.clock.elapsedTime * 0.18;
    ref.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.22) * 0.18;
  });

  return (
    <Float speed={1.2} rotationIntensity={0.22} floatIntensity={0.32}>
      <mesh ref={ref}>
        <torusGeometry args={[2.1, 0.018, 24, 180]} />
        <meshStandardMaterial color="#f4f1ea" emissive="#6f6557" emissiveIntensity={0.35} roughness={0.45} />
      </mesh>
    </Float>
  );
}

function Particles() {
  const ref = useRef<THREE.Points>(null);
  const positions = new Float32Array(900 * 3);

  for (let i = 0; i < 900; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 8;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 8;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 8;
  }

  useFrame((state) => {
    if (!ref.current) return;
    ref.current.rotation.y = state.clock.elapsedTime * 0.025;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.012} color="#f4f1ea" transparent opacity={0.44} />
    </points>
  );
}

export default function OuroborosScene() {
  return (
    <Canvas camera={{ position: [0, 0, 5.2], fov: 45 }}>
      <ambientLight intensity={0.7} />
      <pointLight position={[3, 3, 3]} intensity={2.2} color="#f4f1ea" />
      <pointLight position={[-4, -2, 2]} intensity={1.1} color="#746c60" />
      <Ring />
      <Particles />
      <Stars radius={38} depth={18} count={800} factor={1.4} saturation={0} fade speed={0.25} />
    </Canvas>
  );
}
